This archive contains disk images for various versions of Don Worth�s seminal �Beneath Apple Manor�, a proto-Roguelike (BAM was published two years before Rogue) for the Apple II.

BAM DISK DISTRIBUTION PD1 3.2

This floppy contains the disk and tape distributions of the first version of Beneath Apple Manor, published in 1978 through Don�s company, The Software Factory.  Side 1 is the floppy version (which I believe is identical to the images already floating around the various Apple II content aggregation sites).  Side 2 is the less-commonly-seen cassette version. DOS 3.2 13 sector images.

BAM SPECIAL EDITION PS 3.3

This is the source code for the Special Edition of Beneath Apple Manor, an enhanced version of the original.  BAM:SE was published in 1982 by Quality Software and features high-resolution graphics and improved gameplay. DOS 3.3 images.

NOTE: The FC5025 reported an error on side 1 during the imaging process and the file �CORRIDOR� is corrupt.

BAMSE MOCKUP

This is the distribution diskette for the Special Edition sold by Quality Software and is not copy protected.
