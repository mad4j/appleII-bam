Beneath Apple Manor (PC version)
Keyboard Command Summary
Home of the Underdogs
http://www.the-underdogs.org/

COMMAND                                	USAGE COST

N*      North                           DEXTERITY and 1 or 2 turns
S*      South                           DEXTERITY and 1 or 2 turns
E*      East                            DEXTERITY and 1 or 2 turns
W*      West                            DEXTERITY and 1 or 2 turns
R*      Run away in panic          	Half of DEXTERITY and 1 turn
B*      Bash door            		STRENGTH and 1 turn
K*      Knock at door     		STRENGTH and 1 turn
O       Open door                    	-
L       Listen at door              	-
I       Search for secret passages 	3 turns
A*      Attack a monster              	STRENGTH and 1 turn
O*      Open treasure                   1 turn (BODY if trapped)
D       Drop gold                      	Gold lost
1-9     Wait # turns                	# turns
0       Wait to rest        		0 or several turns
?       Status of player                -
Z*      Zap monster                     up to 1/2 INTELLIGENCE and 1 turn
H       Heal                        	1/10 INTELLIGENCE and 1 turn
X       Xray vision spell               1/4 INTELLIGENCE +15 and 3 turns
T*      Teleportation                   Gold, 1/4 INTELLIGENCE + 5 and 1 turn

(Commands denoted with * can produce noise which attracts monsters within 3 
squares of distance)
-------------------------------------------------------------------------------

Notes:

Play using RGB only.




